import example as e

if __name__ == "__main__":
    e.example()

